import { Observable } from '@nativescript/core';
import { FitnessService } from './services/fitness.service';
import { DatabaseService } from './services/database.service';

export class MainViewModel extends Observable {
  private fitnessService: FitnessService;
  private databaseService: DatabaseService;
  
  private _steps: number = 0;
  private _activeMinutes: number = 0;
  private _stepsGoal: number = 10000;
  private _activeMinutesGoal: number = 60;
  private _achievements: Array<any> = [];
  private _friendsActivity: Array<any> = [];

  constructor() {
    super();
    
    this.fitnessService = new FitnessService();
    this.databaseService = new DatabaseService();
    
    this.initializeHealthTracking();
    this.startPeriodicUpdates();
  }

  async initializeHealthTracking() {
    const authorized = await this.fitnessService.requestAuthorization();
    if (authorized) {
      await this.updateFitnessData();
    }
  }

  private startPeriodicUpdates() {
    setInterval(() => {
      this.updateFitnessData();
    }, 5 * 60 * 1000); // Update every 5 minutes
  }

  async updateFitnessData() {
    this.steps = await this.fitnessService.getTodaySteps();
    this.activeMinutes = await this.fitnessService.getActiveMinutes();
    
    // Save to cloud
    await this.databaseService.saveActivity('current_user_id', 'steps', this.steps);
    await this.databaseService.saveActivity('current_user_id', 'activeMinutes', this.activeMinutes);
    
    this.checkAchievements();
  }

  private checkAchievements() {
    if (this.steps >= this._stepsGoal && !this._achievements.find(a => a.id === 'daily_steps')) {
      this._achievements.push({
        id: 'daily_steps',
        title: 'Daily Step Goal Achieved!',
        description: 'You've reached your daily step goal of ' + this._stepsGoal + ' steps!'
      });
      this.notifyPropertyChange('achievements', this._achievements);
    }
  }

  get steps(): number {
    return this._steps;
  }

  set steps(value: number) {
    if (this._steps !== value) {
      this._steps = value;
      this.notifyPropertyChange('steps', value);
      this.notifyPropertyChange('stepsProgress', (value / this._stepsGoal) * 100);
    }
  }

  get activeMinutes(): number {
    return this._activeMinutes;
  }

  set activeMinutes(value: number) {
    if (this._activeMinutes !== value) {
      this._activeMinutes = value;
      this.notifyPropertyChange('activeMinutes', value);
      this.notifyPropertyChange('activeMinutesProgress', (value / this._activeMinutesGoal) * 100);
    }
  }

  get achievements(): Array<any> {
    return this._achievements;
  }

  get friendsActivity(): Array<any> {
    return this._friendsActivity;
  }

  startWorkout() {
    // Implement workout tracking logic
    console.log('Starting workout session...');
  }
}