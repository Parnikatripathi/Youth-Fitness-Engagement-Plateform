import { Observable } from '@nativescript/core';
import { Health } from '@nativescript/health-data';

export class FitnessService extends Observable {
  private health: Health;

  constructor() {
    super();
    this.health = new Health();
  }

  async requestAuthorization(): Promise<boolean> {
    try {
      const authorized = await this.health.requestAuthorization([
        'steps',
        'distance',
        'activity',
        'heartRate'
      ]);
      return authorized;
    } catch (error) {
      console.error('Health authorization error:', error);
      return false;
    }
  }

  async getTodaySteps(): Promise<number> {
    try {
      const now = new Date();
      const startOfDay = new Date(now.setHours(0, 0, 0, 0));
      
      const steps = await this.health.query({
        startDate: startOfDay,
        endDate: new Date(),
        dataType: 'steps'
      });
      
      return steps.reduce((total, current) => total + current.value, 0);
    } catch (error) {
      console.error('Error getting steps:', error);
      return 0;
    }
  }

  async getActiveMinutes(): Promise<number> {
    try {
      const now = new Date();
      const startOfDay = new Date(now.setHours(0, 0, 0, 0));
      
      const activity = await this.health.query({
        startDate: startOfDay,
        endDate: new Date(),
        dataType: 'activity'
      });
      
      return activity.reduce((total, current) => {
        if (current.value > 1) { // Moderate to vigorous activity
          return total + current.duration;
        }
        return total;
      }, 0);
    } catch (error) {
      console.error('Error getting active minutes:', error);
      return 0;
    }
  }
}