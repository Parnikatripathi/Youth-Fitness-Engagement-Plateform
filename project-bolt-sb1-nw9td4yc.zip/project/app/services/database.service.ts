import { createClient } from '@supabase/supabase-js';

export class DatabaseService {
  private supabase;

  constructor() {
    this.supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_KEY
    );
  }

  async saveActivity(userId: string, type: string, value: number) {
    try {
      const { data, error } = await this.supabase
        .from('activities')
        .insert([
          {
            user_id: userId,
            type,
            value,
            timestamp: new Date()
          }
        ]);

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error saving activity:', error);
      throw error;
    }
  }

  async getDailyProgress(userId: string) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    try {
      const { data, error } = await this.supabase
        .from('activities')
        .select('*')
        .eq('user_id', userId)
        .gte('timestamp', today.toISOString());

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error getting daily progress:', error);
      throw error;
    }
  }
}