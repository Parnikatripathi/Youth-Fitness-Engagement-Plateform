export interface User {
  id: string;
  username: string;
  age: number;
  height: number;
  weight: number;
  dailyStepGoal: number;
  dailyActiveMinutesGoal: number;
}