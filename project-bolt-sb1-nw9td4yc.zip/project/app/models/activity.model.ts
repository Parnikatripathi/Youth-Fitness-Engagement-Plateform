export interface Activity {
  id: string;
  userId: string;
  type: 'steps' | 'activeMinutes' | 'workout';
  value: number;
  timestamp: Date;
}