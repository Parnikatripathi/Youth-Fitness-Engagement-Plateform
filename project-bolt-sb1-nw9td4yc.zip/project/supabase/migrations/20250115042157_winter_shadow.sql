/*
  # Initial Schema Setup for Youth Fitness Platform

  1. New Tables
    - users
      - id (uuid, primary key)
      - username (text)
      - age (integer)
      - height (float)
      - weight (float)
      - daily_step_goal (integer)
      - daily_active_minutes_goal (integer)
      - created_at (timestamp)
    
    - activities
      - id (uuid, primary key)
      - user_id (uuid, foreign key)
      - type (text)
      - value (float)
      - timestamp (timestamp)
      - created_at (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for user data access
*/

-- Create users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  age integer,
  height float,
  weight float,
  daily_step_goal integer DEFAULT 10000,
  daily_active_minutes_goal integer DEFAULT 60,
  created_at timestamptz DEFAULT now()
);

-- Create activities table
CREATE TABLE activities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  type text NOT NULL,
  value float NOT NULL,
  timestamp timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can read own activities"
  ON activities
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own activities"
  ON activities
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_activities_user_timestamp ON activities(user_id, timestamp);
CREATE INDEX idx_activities_type ON activities(type);